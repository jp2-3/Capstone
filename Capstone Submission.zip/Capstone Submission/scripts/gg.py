import seaborn as sns
import matplotlib.pyplot as plt
import numpy as pd

# Clean and prep (if not already done)
df = pd.read_csv('MainTable.csv')
df = df.dropna(subset=['Attempt', 'Score'])

# Ensure numeric
df['Attempt'] = pd.to_numeric(df['Attempt'], errors='coerce')
df['Score'] = pd.to_numeric(df['Score'], errors='coerce')

# Plot with regression line
plt.figure(figsize=(8, 6))
sns.regplot(data=df, x='Attempt', y='Score', scatter_kws={'alpha': 0.6}, line_kws={'color': 'red'})

plt.title('Trend Between Attempts and Score')
plt.xlabel('Number of Attempts')
plt.ylabel('Score')
plt.grid(True)
plt.tight_layout()
plt.show()
