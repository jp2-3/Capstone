import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_squared_error, r2_score

# Load data
df = pd.read_csv('MainTable.csv')

# Clean up any bad data
df = df.dropna(subset=['SubjectID', 'ProblemID', 'Attempt', 'Score'])

# Encode SubjectID and ProblemID
le_subject = LabelEncoder()
le_problem = LabelEncoder()

df['SubjectID_encoded'] = le_subject.fit_transform(df['SubjectID'])
df['ProblemID_encoded'] = le_problem.fit_transform(df['ProblemID'])

# Features and target
X = df[['SubjectID_encoded', 'ProblemID_encoded', 'Attempt']]
y = df['Score']

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create and train model
model = LinearRegression()
model.fit(X_train, y_train)

# Predict
y_pred = model.predict(X_test)

# Evaluation
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print("Model Evaluation:")
print(f"Mean Squared Error: {mse:.4f}")
print(f"R^2 Score: {r2:.4f}")

# Example prediction
subject_id_input = input("Enter Subject ID: ")
problem_id_input = input("Enter Problem ID: ")
attempt_input = float(input("Enter number of attempts: "))

# Encode the inputs
subject_encoded = le_subject.transform([subject_id_input])[0]
problem_encoded = le_problem.transform([problem_id_input])[0]

# Predict score
score_prediction = model.predict([[subject_encoded, problem_encoded, attempt_input]])
print(f"Predicted Score: {score_prediction[0]:.2f}")
