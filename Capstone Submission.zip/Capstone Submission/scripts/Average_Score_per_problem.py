import pandas as pd

df = pd.read_csv('MainTable.csv')
df = df.dropna(subset=['ProblemID', 'Score'])

avg_scores = df.groupby('ProblemID')['Score'].mean().reset_index()
avg_scores.rename(columns={'Score': 'AverageScore'}, inplace=True)

avg_scores.to_csv('Average_Score_Per_Problem.csv', index=False)
